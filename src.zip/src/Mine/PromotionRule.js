//代理规范
import React, {useState} from 'react';

import {
  Text,
  View,
  TextInput,
  ScrollView,
  Image,
  Modal,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
} from 'react-native';
function PromotionRule(params) {
  return <View style={styles.container}></View>;
}
export default PromotionRule;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
  },
});
