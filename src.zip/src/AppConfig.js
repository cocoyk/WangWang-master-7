import {Platform} from 'react-native';
// import { PLATFORM_TEST_VERSION, PLATFORM_CHANNEL } from "./util/Platform";

// // 应用名
// export const APP_NAME = "逍遥团长";

// // 是否是测试版本
// export const TEST_VERSION = PLATFORM_TEST_VERSION;

// // 渠道名
// export const CHANNEL = PLATFORM_CHANNEL;

// // 签到激励视频 TT:穿山甲 SIGN:SIGMOB TX:腾讯
// export const SIGN_VIDEO_AD = "TT";

// // 0:nolog 1:verbose 2:error
// export const LOG_LEVEL = 1;

// // log tag
// export const LOG_TAG = "[[==MyApplication==]]";

// // 微信appkey
// export const WECHAT_KEY = "wx70bb76da48119019";

// // 微信小程序id
// export const WECHAT_MINI_KEY = "gh_2412ddeaeb59";

// // 微信小程序版本 0正式 1测试 2体验
// export const WECHAT_MINI_TYPE = TEST_VERSION ? 2 : 0

// // 友盟appkey
// export const UMENG_KEY = Platform.select({
//   android: "5c885f753fc195995a0010b0",
//   ios: "5cceb4fd3fc1954be0001119"
// });

// // 友盟推送密钥
// export const UMENG_SECRET = Platform.select({
//   android: "9943f6fc780d9d66d2aa8349c3c9e16d",
//   ios: "nfijrk46uvpslu6jblbyzyvhi7h9okih"
// });

// // 闲玩广告sdk appid
// export const XIANWAN_ID = "3390";

// // 闲玩广告sdk appsecret
// export const XIANWAN_SECRET = "arr7knw9uner34fg";

// // 幂动广告sdk appid
// export const MD_ID = "175";

// // 幂动广告sdk appsecret
// export const MD_SECRET = "87cd939ec622dc2";

// // sigmob广告sdk appid
// export const SIGMOB_ID = Platform.select({
//   android: "1428", //"1428"
//   ios: "1255" //"1503"
// });

// // sigmob appkey
// export const SIGMOB_KEY = Platform.select({
//   android: "8445df8c58c2b405", //"8445df8c58c2b405"
//   ios: "df52b75092d98731" //"bdb82459f21312f1"
// });

// // sigmob 视频广告单元
// export const SIGMOB_VIDEO_AD = Platform.select({
//   android: "e243e0198c7", //"e243e0198c7"
//   ios: "df061467766" //"e2a08ba7f45"
// });

// // sigmob 插屏广告单元
// export const SIGMOB_SPLASH_AD = Platform.select({
//   android: "e244023263e", //"e244023263e"
//   ios: "e04d1a0137a" // "e2a08f4c65b"
// });

// // 穿山甲广告sdk ttad appid
// export const TTAD_ID = "5017036"; //5017036

// // 穿山甲 视频广告
// export const TTAD_VIDEO_AD = "917036779"; //"917036779"

// // 穿山甲 开屏广告
// export const TTAD_SPLASH_AD = "817036124"; //"817036124"

// // 穿山甲 插屏广告
// export const TTAD_INTERACTION_AD = "917036328"; //"917036328"

// // 腾讯广告 appid
// export const TXAD_ID = "1109093189";

// // 腾讯广告 视频广告
// export const TXAD_VIDEO_AD = "9080066626802150";

// // 腾讯广告 开屏广告
// export const TXAD_SPLASH_AD = "3000662519584680";

// // 腾讯广告 插屏广告
// export const TXAD_INTERACTION_AD = "4040065509388906";

// // 淘金广告 appid
// export const TJAD_APPID = "322";

// // 淘金广告 appkey
// export const TJAD_APPKEY = "e8cd4720d7c986eb39acf52dfd46b8de";

// // 百度广告 appid
// export const BDAD_APPID = "aa540bc6";

// // 百度广告 视频广告
// export const BDAD_VIDEO_ID = "6358386";

// // 百度广告 开屏广告
// export const BDAD_SPLASH_ID = "6358384";

// // 百度广告 插屏广告
// export const BDAD_INTERACTION_ID = "6358385";

// // 推啊sdk appkey
// export const TA_APP_KEY = "4FYm7qyNsReHsThLRxi7zkqPRCpE";

// // 推啊sdk appkey
// export const TA_APP_SECRET = "3Wo7xjihzo8pN5p7ePyUmMqNQ87n4pyHgRq6ZDD";

// 服务器域名
// export const APP_BASE_URL = TEST_VERSION
//   ? 'https://fanli.beta.xiaoyaoshidai.com'
//   : 'https://fanli.xiaoyaoshidai.com';
// export const APP_BASE_URL = TEST_VERSION ? "http://192.168.0.144:8000" : "https://fanli.xiaoyaoshidai.com";
export const APP_BASE_URL = 'https://api.wwzg01.com';
